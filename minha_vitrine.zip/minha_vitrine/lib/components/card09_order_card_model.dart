import '/flutter_flow/flutter_flow_util.dart';
import 'card09_order_card_widget.dart' show Card09OrderCardWidget;
import 'package:flutter/material.dart';

class Card09OrderCardModel extends FlutterFlowModel<Card09OrderCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
