import '/flutter_flow/flutter_flow_util.dart';
import 'card26_wrap_cards_widget.dart' show Card26WrapCardsWidget;
import 'package:flutter/material.dart';

class Card26WrapCardsModel extends FlutterFlowModel<Card26WrapCardsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
