import '/flutter_flow/flutter_flow_util.dart';
import 'excluir_categoria_pop_up_warning_widget.dart'
    show ExcluirCategoriaPopUpWarningWidget;
import 'package:flutter/material.dart';

class ExcluirCategoriaPopUpWarningModel
    extends FlutterFlowModel<ExcluirCategoriaPopUpWarningWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
