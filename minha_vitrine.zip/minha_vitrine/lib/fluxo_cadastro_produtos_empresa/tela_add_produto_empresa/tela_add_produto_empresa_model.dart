import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'tela_add_produto_empresa_widget.dart' show TelaAddProdutoEmpresaWidget;
import 'package:flutter/material.dart';

class TelaAddProdutoEmpresaModel
    extends FlutterFlowModel<TelaAddProdutoEmpresaWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue1;
  // State field(s) for SwitchListTile widget.
  bool? switchListTileValue2;
  // State field(s) for RadioButton widget.
  FormFieldController<String>? radioButtonValueController;
  // State field(s) for inputNomeProduto widget.
  FocusNode? inputNomeProdutoFocusNode;
  TextEditingController? inputNomeProdutoTextController;
  String? Function(BuildContext, String?)?
      inputNomeProdutoTextControllerValidator;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // State field(s) for inputDescricaoProduto widget.
  FocusNode? inputDescricaoProdutoFocusNode;
  TextEditingController? inputDescricaoProdutoTextController;
  String? Function(BuildContext, String?)?
      inputDescricaoProdutoTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  // Stores action output result for [Backend Call - API (CadastrarProduto)] action in Button-salvar widget.
  ApiCallResponse? apiResultqs2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    inputNomeProdutoFocusNode?.dispose();
    inputNomeProdutoTextController?.dispose();

    inputDescricaoProdutoFocusNode?.dispose();
    inputDescricaoProdutoTextController?.dispose();

    textFieldFocusNode1?.dispose();
    textController3?.dispose();

    textFieldFocusNode2?.dispose();
    textController4?.dispose();
  }

  /// Additional helper methods.
  String? get radioButtonValue => radioButtonValueController?.value;
}
