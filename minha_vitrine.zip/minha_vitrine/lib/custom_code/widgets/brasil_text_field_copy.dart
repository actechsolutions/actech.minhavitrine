// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/services.dart';

class BrasilTextFieldCopy extends StatefulWidget {
  const BrasilTextFieldCopy({
    super.key,
    this.width,
    this.height,
    required this.value,
    required this.backgroundColor,
    required this.textSize,
    required this.textColor,
    required this.focusedBorderColor,
    required this.errorBorderColor,
    required this.corDaBorda,
  });

  final double? width;
  final double? height;
  final String value;
  final Color backgroundColor;
  final double textSize;
  final Color textColor;
  final Color focusedBorderColor;
  final Color errorBorderColor;
  final Color corDaBorda;

  @override
  State<BrasilTextFieldCopy> createState() => _BrasilTextFieldCopyState();
}

class _BrasilTextFieldCopyState extends State<BrasilTextFieldCopy> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      initialValue: widget.value,
      keyboardType: TextInputType.number,
      inputFormatters: [
        CurrencyTextInputFormatter.currency(
          locale: 'pt_BR',
          decimalDigits: 2,
          symbol: 'R\$',
          enableNegative: true,
        ),
        LengthLimitingTextInputFormatter(16),
      ],
      style: TextStyle(
          fontWeight: FontWeight.normal,
          color: widget.textColor,
          fontSize: widget.textSize),
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.corDaBorda),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.focusedBorderColor),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.errorBorderColor),
        ),
        filled: true,
        fillColor: widget.backgroundColor,
      ),
      onChanged: (text) {
        print("valorPreco");
        print(text);
        FFAppState().valorPreco = text;
      },
    );
  }
}
