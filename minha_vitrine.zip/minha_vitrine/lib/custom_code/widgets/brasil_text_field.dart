// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/services.dart';

class BrasilTextField extends StatefulWidget {
  const BrasilTextField({
    super.key,
    this.width,
    this.height,
    required this.valor,
    required this.corFundo,
    required this.tamanhoTexto,
    required this.corTexto,
    required this.focusBorderColor,
    required this.erroBorderColor,
    required this.colorBorder,
  });

  final double? width;
  final double? height;
  final String valor;
  final Color corFundo;
  final double tamanhoTexto;
  final Color corTexto;
  final Color focusBorderColor;
  final Color erroBorderColor;
  final Color colorBorder;

  @override
  State<BrasilTextField> createState() => _BrasilTextFieldState();
}

class _BrasilTextFieldState extends State<BrasilTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      initialValue: widget.valor,
      keyboardType: TextInputType.number,
      inputFormatters: [
        CurrencyTextInputFormatter.currency(
          locale: 'pt_BR',
          decimalDigits: 2,
          symbol: 'R\$',
          enableNegative: true,
        ),
        LengthLimitingTextInputFormatter(16),
      ],
      style: TextStyle(
        fontWeight: FontWeight.normal,
        color: widget.corTexto,
        fontSize: widget.tamanhoTexto,
      ),
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.colorBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.focusBorderColor),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: widget.erroBorderColor),
        ),
        filled: true,
        fillColor: widget.corFundo,
      ),
      onChanged: (text) {
        print("valor Formatado");
        print(text);
        FFAppState().valorFormatado = text;
        // Use a propriedade onChanged para atualizar o estado do widget
        // ou fazer qualquer outra lógica necessária.
        // Se desejar atualizar o estado global, você pode usar FFAppState().valorFormatado = text;
      },
    );
  }
}
