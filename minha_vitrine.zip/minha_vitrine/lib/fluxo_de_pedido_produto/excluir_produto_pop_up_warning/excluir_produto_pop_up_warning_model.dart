import '/flutter_flow/flutter_flow_util.dart';
import 'excluir_produto_pop_up_warning_widget.dart'
    show ExcluirProdutoPopUpWarningWidget;
import 'package:flutter/material.dart';

class ExcluirProdutoPopUpWarningModel
    extends FlutterFlowModel<ExcluirProdutoPopUpWarningWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
