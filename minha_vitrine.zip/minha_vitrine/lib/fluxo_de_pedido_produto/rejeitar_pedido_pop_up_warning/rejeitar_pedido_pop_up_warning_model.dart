import '/flutter_flow/flutter_flow_util.dart';
import 'rejeitar_pedido_pop_up_warning_widget.dart'
    show RejeitarPedidoPopUpWarningWidget;
import 'package:flutter/material.dart';

class RejeitarPedidoPopUpWarningModel
    extends FlutterFlowModel<RejeitarPedidoPopUpWarningWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
