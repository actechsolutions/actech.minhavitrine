// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VariacaoStruct extends BaseStruct {
  VariacaoStruct({
    String? precoVariacao,
    String? descricaoVariacao,
  })  : _precoVariacao = precoVariacao,
        _descricaoVariacao = descricaoVariacao;

  // "precoVariacao" field.
  String? _precoVariacao;
  String get precoVariacao => _precoVariacao ?? '';
  set precoVariacao(String? val) => _precoVariacao = val;
  bool hasPrecoVariacao() => _precoVariacao != null;

  // "descricaoVariacao" field.
  String? _descricaoVariacao;
  String get descricaoVariacao => _descricaoVariacao ?? '';
  set descricaoVariacao(String? val) => _descricaoVariacao = val;
  bool hasDescricaoVariacao() => _descricaoVariacao != null;

  static VariacaoStruct fromMap(Map<String, dynamic> data) => VariacaoStruct(
        precoVariacao: data['precoVariacao'] as String?,
        descricaoVariacao: data['descricaoVariacao'] as String?,
      );

  static VariacaoStruct? maybeFromMap(dynamic data) =>
      data is Map ? VariacaoStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'precoVariacao': _precoVariacao,
        'descricaoVariacao': _descricaoVariacao,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'precoVariacao': serializeParam(
          _precoVariacao,
          ParamType.String,
        ),
        'descricaoVariacao': serializeParam(
          _descricaoVariacao,
          ParamType.String,
        ),
      }.withoutNulls;

  static VariacaoStruct fromSerializableMap(Map<String, dynamic> data) =>
      VariacaoStruct(
        precoVariacao: deserializeParam(
          data['precoVariacao'],
          ParamType.String,
          false,
        ),
        descricaoVariacao: deserializeParam(
          data['descricaoVariacao'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'VariacaoStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is VariacaoStruct &&
        precoVariacao == other.precoVariacao &&
        descricaoVariacao == other.descricaoVariacao;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([precoVariacao, descricaoVariacao]);
}

VariacaoStruct createVariacaoStruct({
  String? precoVariacao,
  String? descricaoVariacao,
}) =>
    VariacaoStruct(
      precoVariacao: precoVariacao,
      descricaoVariacao: descricaoVariacao,
    );
