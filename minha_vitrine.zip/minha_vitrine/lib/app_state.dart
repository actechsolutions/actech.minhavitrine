import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _imageLogotipo = prefs.getString('ff_imageLogotipo') ?? _imageLogotipo;
    });
    _safeInit(() {
      _listaFormaDePagamento =
          prefs.getStringList('ff_listaFormaDePagamento') ??
              _listaFormaDePagamento;
    });
    _safeInit(() {
      _diaDaSemanaVariable =
          prefs.getString('ff_diaDaSemanaVariable') ?? _diaDaSemanaVariable;
    });
    _safeInit(() {
      _idUser = prefs.getInt('ff_idUser') ?? _idUser;
    });
    _safeInit(() {
      _listaCategoria = prefs.getStringList('ff_listaCategoria')?.map((x) {
            try {
              return jsonDecode(x);
            } catch (e) {
              print("Can't decode persisted json. Error: $e.");
              return {};
            }
          }).toList() ??
          _listaCategoria;
    });
    _safeInit(() {
      _horarioEntrada = prefs.getString('ff_horarioEntrada') ?? _horarioEntrada;
    });
    _safeInit(() {
      _horarioSaida = prefs.getString('ff_horarioSaida') ?? _horarioSaida;
    });
    _safeInit(() {
      _entradaAlmoco = prefs.getString('ff_entradaAlmoco') ?? _entradaAlmoco;
    });
    _safeInit(() {
      _saidaAlmoco = prefs.getString('ff_saidaAlmoco') ?? _saidaAlmoco;
    });
    _safeInit(() {
      _onUploadOperationPhotoCounter =
          prefs.getInt('ff_onUploadOperationPhotoCounter') ??
              _onUploadOperationPhotoCounter;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _imageLogotipo =
      'https://static3.depositphotos.com/1000363/104/i/450/depositphotos_1045236-stock-photo-free-button.jpg';
  String get imageLogotipo => _imageLogotipo;
  set imageLogotipo(String value) {
    _imageLogotipo = value;
    prefs.setString('ff_imageLogotipo', value);
  }

  List<String> _listaFormaDePagamento = [];
  List<String> get listaFormaDePagamento => _listaFormaDePagamento;
  set listaFormaDePagamento(List<String> value) {
    _listaFormaDePagamento = value;
    prefs.setStringList('ff_listaFormaDePagamento', value);
  }

  void addToListaFormaDePagamento(String value) {
    _listaFormaDePagamento.add(value);
    prefs.setStringList('ff_listaFormaDePagamento', _listaFormaDePagamento);
  }

  void removeFromListaFormaDePagamento(String value) {
    _listaFormaDePagamento.remove(value);
    prefs.setStringList('ff_listaFormaDePagamento', _listaFormaDePagamento);
  }

  void removeAtIndexFromListaFormaDePagamento(int index) {
    _listaFormaDePagamento.removeAt(index);
    prefs.setStringList('ff_listaFormaDePagamento', _listaFormaDePagamento);
  }

  void updateListaFormaDePagamentoAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _listaFormaDePagamento[index] = updateFn(_listaFormaDePagamento[index]);
    prefs.setStringList('ff_listaFormaDePagamento', _listaFormaDePagamento);
  }

  void insertAtIndexInListaFormaDePagamento(int index, String value) {
    _listaFormaDePagamento.insert(index, value);
    prefs.setStringList('ff_listaFormaDePagamento', _listaFormaDePagamento);
  }

  String _Cidade = '';
  String get Cidade => _Cidade;
  set Cidade(String value) {
    _Cidade = value;
  }

  String _Bairro = '';
  String get Bairro => _Bairro;
  set Bairro(String value) {
    _Bairro = value;
  }

  String _Estado = '';
  String get Estado => _Estado;
  set Estado(String value) {
    _Estado = value;
  }

  bool _ResutadoCEP = false;
  bool get ResutadoCEP => _ResutadoCEP;
  set ResutadoCEP(bool value) {
    _ResutadoCEP = value;
  }

  String _mascara = '';
  String get mascara => _mascara;
  set mascara(String value) {
    _mascara = value;
  }

  String _diaDaSemanaVariable = '';
  String get diaDaSemanaVariable => _diaDaSemanaVariable;
  set diaDaSemanaVariable(String value) {
    _diaDaSemanaVariable = value;
    prefs.setString('ff_diaDaSemanaVariable', value);
  }

  int _idUser = 0;
  int get idUser => _idUser;
  set idUser(int value) {
    _idUser = value;
    prefs.setInt('ff_idUser', value);
  }

  List<dynamic> _listaCategoria = [];
  List<dynamic> get listaCategoria => _listaCategoria;
  set listaCategoria(List<dynamic> value) {
    _listaCategoria = value;
    prefs.setStringList(
        'ff_listaCategoria', value.map((x) => jsonEncode(x)).toList());
  }

  void addToListaCategoria(dynamic value) {
    _listaCategoria.add(value);
    prefs.setStringList('ff_listaCategoria',
        _listaCategoria.map((x) => jsonEncode(x)).toList());
  }

  void removeFromListaCategoria(dynamic value) {
    _listaCategoria.remove(value);
    prefs.setStringList('ff_listaCategoria',
        _listaCategoria.map((x) => jsonEncode(x)).toList());
  }

  void removeAtIndexFromListaCategoria(int index) {
    _listaCategoria.removeAt(index);
    prefs.setStringList('ff_listaCategoria',
        _listaCategoria.map((x) => jsonEncode(x)).toList());
  }

  void updateListaCategoriaAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    _listaCategoria[index] = updateFn(_listaCategoria[index]);
    prefs.setStringList('ff_listaCategoria',
        _listaCategoria.map((x) => jsonEncode(x)).toList());
  }

  void insertAtIndexInListaCategoria(int index, dynamic value) {
    _listaCategoria.insert(index, value);
    prefs.setStringList('ff_listaCategoria',
        _listaCategoria.map((x) => jsonEncode(x)).toList());
  }

  String _time = '';
  String get time => _time;
  set time(String value) {
    _time = value;
  }

  String _horarioEntrada = '';
  String get horarioEntrada => _horarioEntrada;
  set horarioEntrada(String value) {
    _horarioEntrada = value;
    prefs.setString('ff_horarioEntrada', value);
  }

  String _horarioSaida = '';
  String get horarioSaida => _horarioSaida;
  set horarioSaida(String value) {
    _horarioSaida = value;
    prefs.setString('ff_horarioSaida', value);
  }

  String _entradaAlmoco = '';
  String get entradaAlmoco => _entradaAlmoco;
  set entradaAlmoco(String value) {
    _entradaAlmoco = value;
    prefs.setString('ff_entradaAlmoco', value);
  }

  String _saidaAlmoco = '';
  String get saidaAlmoco => _saidaAlmoco;
  set saidaAlmoco(String value) {
    _saidaAlmoco = value;
    prefs.setString('ff_saidaAlmoco', value);
  }

  dynamic _listaHorarioFuncionamento;
  dynamic get listaHorarioFuncionamento => _listaHorarioFuncionamento;
  set listaHorarioFuncionamento(dynamic value) {
    _listaHorarioFuncionamento = value;
  }

  int _onUploadOperationPhotoCounter = 0;
  int get onUploadOperationPhotoCounter => _onUploadOperationPhotoCounter;
  set onUploadOperationPhotoCounter(int value) {
    _onUploadOperationPhotoCounter = value;
    prefs.setInt('ff_onUploadOperationPhotoCounter', value);
  }

  bool _statusHoraFuncionamento = false;
  bool get statusHoraFuncionamento => _statusHoraFuncionamento;
  set statusHoraFuncionamento(bool value) {
    _statusHoraFuncionamento = value;
  }

  List<String> _precoVariacao = [];
  List<String> get precoVariacao => _precoVariacao;
  set precoVariacao(List<String> value) {
    _precoVariacao = value;
  }

  void addToPrecoVariacao(String value) {
    _precoVariacao.add(value);
  }

  void removeFromPrecoVariacao(String value) {
    _precoVariacao.remove(value);
  }

  void removeAtIndexFromPrecoVariacao(int index) {
    _precoVariacao.removeAt(index);
  }

  void updatePrecoVariacaoAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _precoVariacao[index] = updateFn(_precoVariacao[index]);
  }

  void insertAtIndexInPrecoVariacao(int index, String value) {
    _precoVariacao.insert(index, value);
  }

  List<String> _descricaoVariacao = [];
  List<String> get descricaoVariacao => _descricaoVariacao;
  set descricaoVariacao(List<String> value) {
    _descricaoVariacao = value;
  }

  void addToDescricaoVariacao(String value) {
    _descricaoVariacao.add(value);
  }

  void removeFromDescricaoVariacao(String value) {
    _descricaoVariacao.remove(value);
  }

  void removeAtIndexFromDescricaoVariacao(int index) {
    _descricaoVariacao.removeAt(index);
  }

  void updateDescricaoVariacaoAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    _descricaoVariacao[index] = updateFn(_descricaoVariacao[index]);
  }

  void insertAtIndexInDescricaoVariacao(int index, String value) {
    _descricaoVariacao.insert(index, value);
  }

  String _valorFormatado = '';
  String get valorFormatado => _valorFormatado;
  set valorFormatado(String value) {
    _valorFormatado = value;
  }

  List<VariacaoStruct> _variacao = [];
  List<VariacaoStruct> get variacao => _variacao;
  set variacao(List<VariacaoStruct> value) {
    _variacao = value;
  }

  void addToVariacao(VariacaoStruct value) {
    _variacao.add(value);
  }

  void removeFromVariacao(VariacaoStruct value) {
    _variacao.remove(value);
  }

  void removeAtIndexFromVariacao(int index) {
    _variacao.removeAt(index);
  }

  void updateVariacaoAtIndex(
    int index,
    VariacaoStruct Function(VariacaoStruct) updateFn,
  ) {
    _variacao[index] = updateFn(_variacao[index]);
  }

  void insertAtIndexInVariacao(int index, VariacaoStruct value) {
    _variacao.insert(index, value);
  }

  String _valorPreco = '';
  String get valorPreco => _valorPreco;
  set valorPreco(String value) {
    _valorPreco = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
